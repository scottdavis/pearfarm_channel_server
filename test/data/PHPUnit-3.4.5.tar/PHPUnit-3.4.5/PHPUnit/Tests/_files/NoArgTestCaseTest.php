<?php
class NoArgTestCaseTest extends PHPUnit_Framework_TestCase
{
    public function testNothing()
    {
    }
}
?>
