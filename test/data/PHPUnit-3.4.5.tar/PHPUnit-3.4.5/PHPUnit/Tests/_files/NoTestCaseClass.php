<?php
class NoTestCaseClass
{
}
?>
