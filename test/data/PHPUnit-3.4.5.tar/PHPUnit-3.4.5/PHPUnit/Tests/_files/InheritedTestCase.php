<?php
require_once 'OneTestCase.php';

class InheritedTestCase extends OneTestCase
{
    public function test2()
    {
    }
}
?>
