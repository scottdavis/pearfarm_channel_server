<?php
require_once 'AbstractTest.php';

class ConcreteTest extends AbstractTest
{
    public function testTwo()
    {
    }
}
